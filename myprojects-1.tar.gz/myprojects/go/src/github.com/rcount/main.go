package main

import (
	"fmt"
	"log"
//	"strconv"
	"reflect"

	// Import the redigo/redis package.
	"github.com/gomodule/redigo/redis"
)

func main() {
	conn, err := redis.Dial("tcp", "localhost:6379")
	if err != nil {
		log.Fatal(err)
	}
	// properly closed before exiting the main() function.
	defer conn.Close()

	_, err = conn.Do("SET", "album", 9099)
	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("Electric Ladyland added!")

	strs, err := redis.String(conn.Do("GET", "album"))
	if err != nil {
		log.Fatal(err)
	}

	fmt.Println(reflect.TypeOf(strs))

	// prints [a b ]
	fmt.Println(strs)
//	s1 := strconv.Itoa(strs)
//	fmt.Printf("%v\n",s1)

}
